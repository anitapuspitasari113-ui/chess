package com.oxy.chess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D30)
private val Mint = Color(0xFF62E6B5)
private val Muted = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OxyApp() }
    }
}

@Composable
fun OxyApp() {
    var tab by remember { mutableStateOf("Dashboard") }
    var selected by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var moves by remember { mutableIntStateOf(0) }
    var puzzleAnswer by remember { mutableStateOf("") }
    var puzzleChecked by remember { mutableStateOf(false) }
    val board = remember { mutableStateListOf<String>().apply {
        addAll(listOf("♜","♞","♝","♛","♚","♝","♞","♜"))
        repeat(8) { add("♟") }; repeat(32) { add("") }; repeat(8) { add("♙") }
        addAll(listOf("♖","♘","♗","♕","♔","♗","♘","♖"))
    } }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Mint)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("OXY CHESS", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("CHESS COMPANION  •  LEARN & ANALYZE", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                }
                Surface(color = Color(0xFF18372F), shape = RoundedCornerShape(50)) { Text("● READY", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Dashboard", "Analyze", "Practice").forEach { item ->
                    Surface(color = if (tab == item) Mint else Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f).clickable { tab = item }) {
                        Text(item, Modifier.padding(vertical = 12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = if (tab == item) Bg else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            when (tab) {
                "Dashboard" -> {
                    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("WELCOME BACK", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Play smarter.\nLearn every move.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("A clean companion for chess study, position review, and tactical practice.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("SESSIONS", "${moves}", Modifier.weight(1f))
                                StatCard("MODE", "STUDY", Modifier.weight(1f))
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("QUICK TOOLS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(9.dp))
                    ToolRow("♟", "Position analysis", "Review a position on your own board") { tab = "Analyze" }
                    ToolRow("✦", "Tactics trainer", "Practice a simple checkmate pattern") { tab = "Practice" }
                    Spacer(Modifier.height(12.dp))
                    Text("OXY CHESS works independently. It does not read, modify, or automate Chess.com games.", color = Muted, fontSize = 11.sp)
                }
                "Analyze" -> {
                    Text("BOARD STUDY", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text("Tap a piece, then a destination to make a study move.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    ChessBoard(board, selected) { r, c ->
                        val idx = r * 8 + c
                        val old = selected
                        if (old == null) { if (board[idx].isNotEmpty()) selected = r to c }
                        else {
                            val from = old.first * 8 + old.second
                            if (from != idx) { board[idx] = board[from]; board[from] = ""; moves++ }
                            selected = null
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text("STUDY NOTES", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("Move count: $moves", color = Color.White, modifier = Modifier.padding(top = 5.dp))
                            Text("This board is a visual study pad, not a full legal chess engine. Reset to restore the starting position.", color = Muted, fontSize = 11.sp)
                            TextButton(onClick = { val initial = listOf("♜","♞","♝","♛","♚","♝","♞","♜") + List(8){"♟"} + List(32){""} + List(8){"♙"} + listOf("♖","♘","♗","♕","♔","♗","♘","♖"); board.clear(); board.addAll(initial); selected = null; moves = 0 }) { Text("RESET BOARD", color = Mint) }
                        }
                    }
                }
                else -> {
                    Text("TACTICS TRAINER", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("PUZZLE 01  •  BEGINNER", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text("White to move", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Find the move that gives immediate checkmate in this classic pattern.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(14.dp))
                            Text("Hint: look for the queen's diagonal attack near the enemy king.", color = Mint, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value = puzzleAnswer, onValueChange = { puzzleAnswer = it; puzzleChecked = false }, label = { Text("Your move (example: Qh7#)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Mint, unfocusedBorderColor = Muted))
                            Button(onClick = { puzzleChecked = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Bg)) { Text("CHECK ANSWER", fontWeight = FontWeight.Bold) }
                            if (puzzleChecked) Text("This sample puzzle is a learning prompt. Add a verified position and solution to enable automatic answer checking.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("OXY CHESS  •  VERSION 1.0", Modifier.align(Alignment.CenterHorizontally), color = Color(0xFF64748B), fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Color(0xFF202B40), shape = RoundedCornerShape(14.dp), modifier = modifier) { Column(Modifier.padding(12.dp)) { Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold); Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) } }
}

@Composable fun ToolRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, color = Mint, fontSize = 25.sp); Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(subtitle, color = Muted, fontSize = 11.sp) }
            Text("›", color = Mint, fontSize = 25.sp)
        }
    }
}

@Composable fun ChessBoard(board: List<String>, selected: Pair<Int, Int>?, onSquare: (Int, Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        for (r in 0..7) Row {
            for (c in 0..7) {
                val light = (r + c) % 2 == 1
                val chosen = selected == (r to c)
                Box(Modifier.weight(1f).aspectRatio(1f).background(if (chosen) Color(0xFFB7D66B) else if (light) Color(0xFFE8DCC7) else Color(0xFF78916E)).clickable { onSquare(r,c) }, contentAlignment = Alignment.Center) {
                    Text(board[r*8+c], fontSize = 27.sp, color = if (board[r*8+c] in listOf("♙","♖","♘","♗","♕","♔")) Color.White else Color(0xFF17202A))
                }
            }
        }
    }
}
