# OXY CHESS Android

Android Studio project for the OXY CHESS chess-study companion.

## Build APK without installing Android Studio locally

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build OXY CHESS APK** and run the workflow (or wait for the push build).
4. When the run finishes, open it and download the `OXY-CHESS-debug-apk` artifact.
5. Extract the artifact ZIP; it contains the installable debug APK.

The workflow builds a debug APK. It is not a Play Store release-signed package.
